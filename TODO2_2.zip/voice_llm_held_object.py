"""
[음성 + LLM 프로세스]  voice_llm_held_object.py

두 가지 일을 번갈아 한다.

  1) 마이크를 짧게 계속 녹음 -> Whisper -> 질문이면 Vision에 ROI 요청 -> Gemma -> TTS
  2) Vision이 스스로 보낸 auto 이벤트를 감지 -> Gemma -> TTS (먼저 말 걸기)

실행 (vision_on_request.py와 다른 터미널에서):
    source .venv/bin/activate
    python voice_llm_held_object.py

종료: Ctrl + C
"""

import base64
import json
import os
import subprocess
import time
import wave

import numpy as np
from llama_cpp import Llama
from llama_cpp.llama_chat_format import Gemma4ChatHandler

# ============================ 설정 ============================

# --- Gemma ---
GEMMA_MODEL_PATH = "src/models/Gemma4/google_gemma-4-E2B-it-Q4_K_M.gguf"
MMPROJ_PATH = "src/models/Gemma4/mmproj-google_gemma-4-E2B-it-f16.gguf"
CONTEXT_WINDOW = 2048
MAX_TOKENS = 60

# --- 프로세스 간 파일 ---
REQUEST_PATH = "src/output/request.json"
TEMP_REQUEST_PATH = "src/output/request_tmp.json"
ROI_IMAGE_PATH = "src/output/roi.jpg"
ROI_META_PATH = "src/output/roi_meta.json"
ROI_TIMEOUT = 5.0

# --- STT (whisper.cpp) ---
MIC_DEVICE = "plughw:3,0"
CHUNK_FILE = "src/audio/chunk.wav"
WHISPER_PATH = "whisper.cpp/build-cpu/bin/whisper-cli"
WHISPER_MODEL = "whisper.cpp/models/ggml-base.bin"
CHUNK_SECONDS = 3

RMS_THRESHOLD = 300  # 이보다 조용하면 Whisper를 돌리지 않는다

# --- TTS (Piper) ---
PIPER_PYTHON = ".piper_venv/bin/python"
PIPER_MODEL = "src/models/Piper/ko_KR-kss-medium.onnx"
PIPER_VOLUME = "0.1"
OUTPUT_FILE = "src/audio/response.wav"
SPEAKER_DEVICE = "plughw:3,0"
TTS_COOLDOWN = 1.0

# --- 질문 감지 ---
TRIGGER_KEYWORDS = [
    "뭐", "뭘", "무엇", "무슨", "이게", "이거", "들고", "손에",
]

IGNORE_PHRASES = [
    "시청해", "구독", "감사합니다", "다음 영상", "안녕하세요",
    "MBC", "KBS", "자막",
]


# ============================ STT ============================


def record_chunk():
    subprocess.run(
        [
            "pasuspender", "--",
            "arecord",
            "-D", MIC_DEVICE,
            "-f", "S16_LE",
            "-r", "16000",
            "-c", "1",
            "-d", str(CHUNK_SECONDS),
            CHUNK_FILE,
        ],
        check=True,
        capture_output=True,
    )


def chunk_rms():
    """녹음 구간의 평균 음량. 무음이면 Whisper를 건너뛰기 위해 쓴다."""
    with wave.open(CHUNK_FILE, "rb") as wav:
        frames = wav.readframes(wav.getnframes())

    if not frames:
        return 0.0

    samples = np.frombuffer(frames, dtype=np.int16).astype(np.float32)

    return float(np.sqrt(np.mean(samples ** 2)))


def transcribe():
    result = subprocess.run(
        [
            WHISPER_PATH,
            "-m", WHISPER_MODEL,
            "-f", CHUNK_FILE,
            "-l", "ko",
            "--no-timestamps",
        ],
        text=True,
        capture_output=True,
        check=True,
    )

    lines = []

    for line in result.stdout.splitlines():
        line = line.strip()

        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            continue

        lines.append(line)

    return " ".join(lines)


def is_question(text):
    if not text:
        return False

    for phrase in IGNORE_PHRASES:
        if phrase in text:
            return False

    for keyword in TRIGGER_KEYWORDS:
        if keyword in text:
            return True

    return False


# ============================ TTS ============================


def text_to_speech(text):
    for char in "*_`#\n\r":
        text = text.replace(char, " ")

    text = " ".join(text.split())

    if not text:
        return

    subprocess.run(
        [
            PIPER_PYTHON,
            "-m",
            "piper",

            "-m",
            PIPER_MODEL,

            "-f",
            OUTPUT_FILE,

            "--volume",
            PIPER_VOLUME,

            "--",
            text,
        ],
        check=True,
    )

    subprocess.run(
        [
            "aplay",
            "-D",
            SPEAKER_DEVICE,
            OUTPUT_FILE,
        ],
        check=True,
    )


# ==================== Vision 프로세스와의 핸드셰이크 ====================


def request_roi(question):
    """Vision에 '지금 화면을 캡처해 달라'고 요청한다."""
    with open(TEMP_REQUEST_PATH, "w", encoding="utf-8") as file:
        json.dump(
            {"question": question, "timestamp": time.time()},
            file,
            ensure_ascii=False,
        )

    os.replace(TEMP_REQUEST_PATH, REQUEST_PATH)


def poll_roi(previous_mtime):
    """새 ROI가 있으면 즉시 반환한다. 없으면 기다리지 않는다."""
    if not os.path.exists(ROI_META_PATH):
        return previous_mtime, None

    current = os.path.getmtime(ROI_META_PATH)

    if current == previous_mtime:
        return previous_mtime, None

    with open(ROI_META_PATH, "r", encoding="utf-8") as file:
        meta = json.load(file)

    return current, meta


def wait_for_request_roi(previous_mtime):
    """내가 요청한 ROI가 올 때까지 기다린다. auto 이벤트가 끼어들면 건너뛴다."""
    deadline = time.time() + ROI_TIMEOUT
    mtime = previous_mtime

    while time.time() < deadline:
        mtime, meta = poll_roi(mtime)

        if meta is not None and meta.get("trigger") == "request":
            return mtime, meta

        time.sleep(0.05)

    return mtime, None


# ============================ Prompt ============================


def build_messages(image_data, meta, question):
    proactive = question is None

    if meta["mode"] == "object":
        hint_line = f"참고 정보: 객체 탐지 후보 이름은 {meta['hint']}입니다."

        if proactive:
            system_content = """
                              Instruction:
                              사람이 새로운 물건을 손에 들었다.
                              묻지 않았지만 무엇을 들었는지 먼저 알려주시오.

                              Constraint:
                              참고 정보로 주어진 후보 이름은 틀릴 수 있으므로,
                              반드시 이미지를 우선하여 판단하시오.
                              이미지에서 확실하게 알아볼 수 없으면
                              아무 말도 하지 말고 "없음"이라고만 답하시오.
                              응답은 음성으로 재생되므로 기호나 목록을 쓰지 마시오.

                              Output Format:
                              한국어 한 문장.
                             """

            user_text = f"{hint_line}\n무엇을 들고 있는지 알려주시오."
        else:
            system_content = """
                              Instruction:
                              주어진 이미지는 사람이 손에 들고 있는 물건을 잘라낸 것이다.
                              사용자 질문에 답하시오.

                              Constraint:
                              참고 정보로 주어진 후보 이름은 틀릴 수 있으므로,
                              반드시 이미지를 우선하여 판단하시오.
                              이미지에서 확실하게 알아볼 수 없으면
                              "잘 모르겠습니다"라고 답하시오.
                              응답은 음성으로 재생되므로 기호나 목록을 쓰지 마시오.

                              Output Format:
                              한국어 한 문장.
                             """

            user_text = f"{hint_line}\n질문: {question}"
    else:
        system_content = """
                          Instruction:
                          주어진 이미지는 카메라에 잡힌 사람이다.
                          이 사람이 손에 들고 있는 물건을 보고 사용자 질문에 답하시오.

                          Constraint:
                          손에 들고 있는 물건만 답하고, 배경의 물건은 무시하시오.
                          아무것도 들고 있지 않으면 "아무것도 들고 있지 않습니다"라고 답하시오.
                          이미지에서 확실하게 알아볼 수 없으면
                          "잘 모르겠습니다"라고 답하시오.
                          응답은 음성으로 재생되므로 기호나 목록을 쓰지 마시오.

                          Output Format:
                          한국어 한 문장.
                         """

        user_text = f"질문: {question}"

    return [
        {
            "role": "system",
            "content": system_content,
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": user_text,
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": image_data
                    },
                },
            ],
        },
    ]


def ask_gemma(llm, meta, question):
    with open(ROI_IMAGE_PATH, "rb") as file:
        image_bytes = file.read()

    image_base64 = base64.b64encode(image_bytes).decode("utf-8")
    image_data = "data:image/jpeg;base64," + image_base64

    response = llm.create_chat_completion(
        messages=build_messages(image_data, meta, question),
        max_tokens=MAX_TOKENS,
        temperature=0.0,
    )

    return response["choices"][0]["message"]["content"].strip()


def respond(llm, meta, question):
    """ROI 하나를 받아 답변을 만들고 음성으로 출력한다."""
    if meta["mode"] == "none":
        if question is None:
            return  # 자동 알림인데 사람이 없으면 말하지 않는다

        answer = "카메라에 사람이 보이지 않습니다."
    else:
        label = "자동" if question is None else "응답"
        print(f"[{label}] mode={meta['mode']}  hint={meta['hint']}")

        start = time.time()
        answer = ask_gemma(llm, meta, question)
        print(f"[Gemma] ({time.time() - start:.1f}초)")

        # 자동 알림에서 Gemma가 확신하지 못하면 침묵한다
        if question is None and ("없음" in answer or "모르" in answer):
            print("(확신 부족 -> 발화 생략)\n")
            return

    print(f"{answer}\n")

    text_to_speech(answer)
    time.sleep(TTS_COOLDOWN)


# ============================ main ============================

os.makedirs("src/audio", exist_ok=True)
os.makedirs("src/output", exist_ok=True)

chat_handler = Gemma4ChatHandler(clip_model_path=MMPROJ_PATH)

llm = Llama(
    model_path=GEMMA_MODEL_PATH,
    chat_handler=chat_handler,
    n_gpu_layers=-1,
    n_ctx=CONTEXT_WINDOW,
    n_batch=32,
    n_ubatch=32,
    verbose=False,
)

print("Gemma 로드 완료.")
print("듣고 있습니다. 새로운 물건을 들면 먼저 말을 겁니다.")
print("종료: Ctrl + C\n")

if os.path.exists(ROI_META_PATH):
    roi_mtime = os.path.getmtime(ROI_META_PATH)
else:
    roi_mtime = 0

try:
    while True:
        # ---------- 1. Vision이 먼저 보낸 auto 이벤트 확인 ----------
        roi_mtime, meta = poll_roi(roi_mtime)

        if meta is not None and meta.get("trigger") == "auto":
            print("\n[자동 감지] 새로운 물건")
            respond(llm, meta, None)
            continue

        # ---------- 2. 마이크 듣기 ----------
        record_chunk()

        if chunk_rms() < RMS_THRESHOLD:
            continue

        text = transcribe()

        if not text:
            continue

        print(f"[들림] {text}")

        if not is_question(text):
            continue

        print(f"\n[질문 감지] {text}")

        request_roi(text)

        roi_mtime, meta = wait_for_request_roi(roi_mtime)

        if meta is None:
            print("[오류] Vision 프로세스 응답이 없습니다.\n")
            continue

        respond(llm, meta, text)

except KeyboardInterrupt:
    print("\n음성 프로세스를 종료했습니다.")
