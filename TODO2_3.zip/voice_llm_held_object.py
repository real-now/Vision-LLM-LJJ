"""
[음성 + LLM 프로세스]  voice_llm_held_object.py

마이크를 짧게 계속 녹음해서 Whisper로 받아쓰고, 질문이면 종류를 분류해
Vision에 요청한 뒤 답변을 만들어 Piper TTS로 출력한다.

질문 종류(intent)에 따라 처리 경로가 다르다.

    count     : 개수     -> YOLO 결과만으로 즉답 (Gemma 미사용)
    position  : 위치     -> YOLO 결과만으로 즉답 (Gemma 미사용)
    identity  : 무엇     -> 물건 crop + Gemma
    color     : 색       -> 물건 crop + Gemma
    scene     : 상황설명 -> 프레임 전체 + Gemma

실행 (vision_on_request.py와 다른 터미널에서):
    source .venv/bin/activate
    python voice_llm_held_object.py

종료: Ctrl + C
"""

import base64
import json
import os
import subprocess
import time
import wave
from collections import Counter

import numpy as np
from llama_cpp import Llama
from llama_cpp.llama_chat_format import Gemma4ChatHandler

# ============================ 설정 ============================

# --- Gemma ---
GEMMA_MODEL_PATH = "src/models/Gemma4/google_gemma-4-E2B-it-Q4_K_M.gguf"
MMPROJ_PATH = "src/models/Gemma4/mmproj-google_gemma-4-E2B-it-f16.gguf"
CONTEXT_WINDOW = 2048

# --- 프로세스 간 파일 ---
REQUEST_PATH = "src/output/request.json"
TEMP_REQUEST_PATH = "src/output/request_tmp.json"
ROI_IMAGE_PATH = "src/output/roi.jpg"
ROI_META_PATH = "src/output/roi_meta.json"
ROI_TIMEOUT = 5.0

# --- STT (whisper.cpp) ---
MIC_DEVICE = "plughw:3,0"
CHUNK_FILE = "src/audio/chunk.wav"
WHISPER_PATH = "whisper.cpp/build-cpu/bin/whisper-cli"
WHISPER_MODEL = "whisper.cpp/models/ggml-base.bin"
CHUNK_SECONDS = 3

RMS_THRESHOLD = 300

# --- TTS (Piper) ---
PIPER_PYTHON = ".piper_venv/bin/python"
PIPER_MODEL = "src/models/Piper/ko_KR-kss-medium.onnx"
PIPER_VOLUME = "0.1"
OUTPUT_FILE = "src/audio/response.wav"
SPEAKER_DEVICE = "plughw:3,0"
TTS_COOLDOWN = 1.0

IGNORE_PHRASES = [
    "시청해", "구독", "감사합니다", "다음 영상", "안녕하세요",
    "MBC", "KBS", "자막",
]

# --- 질문 종류 판별 ---
# 위에서부터 순서대로 검사한다. 구체적인 것이 먼저 와야 한다.
# ("무슨 색"은 "무슨"보다, "몇 개"는 "뭐"보다 먼저 걸려야 한다.)
INTENT_KEYWORDS = [
    ("color", ["무슨 색", "무슨색", "색깔", "색은", "색이"]),
    ("count", ["몇 개", "몇개", "몇 명", "몇명", "개수", "몇 사람", "몇"]),
    ("position", ["어디", "왼쪽", "오른쪽", "위치", "어느 쪽", "어느쪽"]),
    ("scene", ["뭐가 보여", "뭐 보여", "상황", "설명해", "설명 해", "무엇이 보"]),
    ("identity", ["뭐야", "뭘까", "뭐지", "무엇", "무슨", "이게", "이거", "들고", "손에"]),
]

# TTS가 영어 클래스명을 어색하게 읽지 않도록 자주 쓰는 것만 한글로 바꾼다.
CLASS_KOR = {
    "person": "사람", "cup": "컵", "bottle": "병", "cell phone": "휴대폰",
    "book": "책", "laptop": "노트북", "mouse": "마우스", "keyboard": "키보드",
    "remote": "리모컨", "scissors": "가위", "banana": "바나나", "apple": "사과",
    "orange": "오렌지", "sandwich": "샌드위치", "backpack": "가방",
    "handbag": "핸드백", "umbrella": "우산", "clock": "시계", "vase": "꽃병",
    "spoon": "숟가락", "fork": "포크", "knife": "칼", "bowl": "그릇",
    "wine glass": "와인잔", "teddy bear": "곰인형", "sports ball": "공",
    "toothbrush": "칫솔", "hair drier": "드라이어", "tie": "넥타이",
    "chair": "의자", "tv": "티비", "potted plant": "화분",
}


def kor(class_name):
    return CLASS_KOR.get(class_name, class_name)


# ============================ STT ============================


def record_chunk():
    subprocess.run(
        [
            "pasuspender", "--",
            "arecord",
            "-D", MIC_DEVICE,
            "-f", "S16_LE",
            "-r", "16000",
            "-c", "1",
            "-d", str(CHUNK_SECONDS),
            CHUNK_FILE,
        ],
        check=True,
        capture_output=True,
    )


def chunk_rms():
    """녹음 구간의 평균 음량. 무음이면 Whisper를 건너뛰기 위해 쓴다."""
    with wave.open(CHUNK_FILE, "rb") as wav:
        frames = wav.readframes(wav.getnframes())

    if not frames:
        return 0.0

    samples = np.frombuffer(frames, dtype=np.int16).astype(np.float32)

    return float(np.sqrt(np.mean(samples ** 2)))


def transcribe():
    result = subprocess.run(
        [
            WHISPER_PATH,
            "-m", WHISPER_MODEL,
            "-f", CHUNK_FILE,
            "-l", "ko",
            "--no-timestamps",
        ],
        text=True,
        capture_output=True,
        check=True,
    )

    lines = []

    for line in result.stdout.splitlines():
        line = line.strip()

        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            continue

        lines.append(line)

    return " ".join(lines)


def classify_intent(text):
    """질문 종류를 정한다. 질문이 아니면 None."""
    if not text:
        return None

    for phrase in IGNORE_PHRASES:
        if phrase in text:
            return None

    for intent, keywords in INTENT_KEYWORDS:
        for keyword in keywords:
            if keyword in text:
                return intent

    return None


# ============================ TTS ============================


def text_to_speech(text):
    for char in "*_`#\n\r":
        text = text.replace(char, " ")

    text = " ".join(text.split())

    if not text:
        return

    subprocess.run(
        [
            PIPER_PYTHON,
            "-m",
            "piper",

            "-m",
            PIPER_MODEL,

            "-f",
            OUTPUT_FILE,

            "--volume",
            PIPER_VOLUME,

            "--",
            text,
        ],
        check=True,
    )

    subprocess.run(
        [
            "aplay",
            "-D",
            SPEAKER_DEVICE,
            OUTPUT_FILE,
        ],
        check=True,
    )


# ==================== Vision 프로세스와의 핸드셰이크 ====================


def request_payload(question, intent):
    with open(TEMP_REQUEST_PATH, "w", encoding="utf-8") as file:
        json.dump(
            {"question": question, "intent": intent, "timestamp": time.time()},
            file,
            ensure_ascii=False,
        )

    os.replace(TEMP_REQUEST_PATH, REQUEST_PATH)


def wait_for_payload(previous_mtime):
    deadline = time.time() + ROI_TIMEOUT

    while time.time() < deadline:
        if os.path.exists(ROI_META_PATH):
            current = os.path.getmtime(ROI_META_PATH)

            if current != previous_mtime:
                with open(ROI_META_PATH, "r", encoding="utf-8") as file:
                    meta = json.load(file)

                return current, meta

        time.sleep(0.05)

    return previous_mtime, None


# ================== Gemma 없이 답하는 질문들 ==================


def answer_count(meta, question):
    """개수는 YOLO 결과에 이미 있다. Gemma를 부를 이유가 없다."""
    detections = meta["detections"]

    if not detections:
        return "탐지된 것이 없습니다."

    # "몇 명"이라고 물으면 사람만 센다
    if "명" in question or "사람" in question:
        count = sum(1 for d in detections if d["class"] == "person")

        if count == 0:
            return "사람이 보이지 않습니다."

        return f"사람이 {count}명 있습니다."

    counts = Counter(d["class"] for d in detections)

    parts = []

    for class_name, count in counts.most_common(4):
        unit = "명" if class_name == "person" else "개"
        parts.append(f"{kor(class_name)} {count}{unit}")

    return ", ".join(parts) + "가 보입니다."


def answer_position(meta, question):
    """위치도 bbox 중심으로 계산된 값이 이미 넘어와 있다."""
    detections = meta["detections"]

    if not detections:
        return "탐지된 것이 없습니다."

    # 사람이 아닌 물건을 우선해서 답한다
    targets = [d for d in detections if d["class"] != "person"]

    if not targets:
        targets = detections

    parts = []

    for detection in targets[:3]:
        parts.append(f"{kor(detection['class'])}은 {detection['zone']}에")

    return ", ".join(parts) + " 있습니다."


# ============================ Gemma ============================


PROMPTS = {
    "identity": (
        """
         Instruction:
         주어진 이미지는 사람이 손에 들고 있는 물건이다.
         이 물건이 무엇인지 판단하시오.

         Constraint:
         참고 정보로 주어진 후보 이름은 틀릴 수 있으므로,
         반드시 이미지를 우선하여 판단하시오.
         알아볼 수 없으면 "잘 모르겠습니다"라고 답하시오.
         응답은 음성으로 재생되므로 기호나 목록을 쓰지 마시오.

         Output Format:
         한국어 한 문장.
        """,
        60,
    ),
    "color": (
        """
         Instruction:
         주어진 이미지에 있는 물건의 색을 판단하시오.

         Constraint:
         색만 답하고 다른 설명을 덧붙이지 마시오.
         여러 색이면 가장 넓은 면적의 색 하나만 답하시오.
         알아볼 수 없으면 "잘 모르겠습니다"라고 답하시오.

         Output Format:
         "빨간색입니다" 처럼 한국어 한 문장.
        """,
        20,
    ),
    "scene": (
        """
         Instruction:
         주어진 이미지를 바탕으로 현재 상황을 설명하시오.

         Constraint:
         이미지에서 확실하게 확인되지 않는 내용은 추측하지 마시오.
         응답은 음성으로 재생되므로 기호나 목록을 쓰지 마시오.

         Output Format:
         한국어 두 문장 이내.
        """,
        100,
    ),
}


def build_messages(image_data, meta):
    intent = meta["intent"]
    system_content, max_tokens = PROMPTS.get(intent, PROMPTS["identity"])

    user_lines = []

    if meta.get("hint"):
        user_lines.append(f"참고 정보: 객체 탐지 후보 이름은 {meta['hint']}입니다.")

    if meta["mode"] == "person":
        user_lines.append("이미지는 사람 전체입니다. 손에 들고 있는 물건만 보십시오.")

    user_lines.append(f"질문: {meta['question']}")

    messages = [
        {
            "role": "system",
            "content": system_content,
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "\n".join(user_lines),
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": image_data
                    },
                },
            ],
        },
    ]

    return messages, max_tokens


def ask_gemma(llm, meta):
    with open(ROI_IMAGE_PATH, "rb") as file:
        image_bytes = file.read()

    image_base64 = base64.b64encode(image_bytes).decode("utf-8")
    image_data = "data:image/jpeg;base64," + image_base64

    messages, max_tokens = build_messages(image_data, meta)

    response = llm.create_chat_completion(
        messages=messages,
        max_tokens=max_tokens,
        temperature=0.0,
    )

    return response["choices"][0]["message"]["content"].strip()


# ============================ 응답 라우팅 ============================


def make_answer(llm, meta, question):
    intent = meta["intent"]

    # 1. Gemma가 필요 없는 질문
    if intent == "count":
        return answer_count(meta, question)

    if intent == "position":
        return answer_position(meta, question)

    # 2. 이미지가 없으면 (사람 미탐지 등) Gemma를 부를 수 없다
    if not meta.get("has_image"):
        return "카메라에 사람이 보이지 않습니다."

    # 3. Gemma 멀티모달
    start = time.time()
    answer = ask_gemma(llm, meta)
    print(f"[Gemma] ({time.time() - start:.1f}초)")

    return answer


# ============================ main ============================

os.makedirs("src/audio", exist_ok=True)
os.makedirs("src/output", exist_ok=True)

chat_handler = Gemma4ChatHandler(clip_model_path=MMPROJ_PATH)

llm = Llama(
    model_path=GEMMA_MODEL_PATH,
    chat_handler=chat_handler,
    n_gpu_layers=-1,
    n_ctx=CONTEXT_WINDOW,
    n_batch=32,
    n_ubatch=32,
    verbose=False,
)

print("Gemma 로드 완료.")
print("듣고 있습니다.")
print('  "이게 뭐야?"        -> 물건 인식')
print('  "무슨 색이야?"      -> 색 판단')
print('  "몇 개 있어?"       -> 개수 (즉답)')
print('  "어디에 있어?"      -> 위치 (즉답)')
print('  "뭐가 보여?"        -> 상황 설명')
print("종료: Ctrl + C\n")

if os.path.exists(ROI_META_PATH):
    payload_mtime = os.path.getmtime(ROI_META_PATH)
else:
    payload_mtime = 0

try:
    while True:
        record_chunk()

        if chunk_rms() < RMS_THRESHOLD:
            continue

        text = transcribe()

        if not text:
            continue

        print(f"[들림] {text}")

        intent = classify_intent(text)

        if intent is None:
            continue

        print(f"\n[질문/{intent}] {text}")

        request_payload(text, intent)

        payload_mtime, meta = wait_for_payload(payload_mtime)

        if meta is None:
            print("[오류] Vision 프로세스 응답이 없습니다.\n")
            continue

        answer = make_answer(llm, meta, text)

        print(f"{answer}\n")

        text_to_speech(answer)
        time.sleep(TTS_COOLDOWN)

except KeyboardInterrupt:
    print("\n음성 프로세스를 종료했습니다.")
