"""
[Vision 프로세스]  vision_on_request.py

카메라에서 YOLO11n(INT8 Engine)으로 객체를 계속 탐지하다가,
음성 프로세스가 request.json을 갱신하면 질문 종류(intent)에 맞는
페이로드를 만들어 저장한다.

    intent = identity  -> 들고 있는 물건만 crop
    intent = color     -> 들고 있는 물건만 crop
    intent = scene     -> 프레임 전체
    intent = count     -> 이미지 불필요 (탐지 목록만)
    intent = position  -> 이미지 불필요 (탐지 목록만)

    l : 수동 캡처 (identity)
    q : 종료

실행:
    source .venv/bin/activate
    python vision_on_request.py
"""

import json
import os

import cv2
from ultralytics import YOLO

# ============================ 설정 ============================

YOLO_MODEL_PATH = "src/models/YOLO/yolo11n_int8.engine"

REQUEST_PATH = "src/output/request.json"

ROI_IMAGE_PATH = "src/output/roi.jpg"
TEMP_ROI_IMAGE_PATH = "src/output/roi_tmp.jpg"
ROI_META_PATH = "src/output/roi_meta.json"
TEMP_ROI_META_PATH = "src/output/roi_meta_tmp.json"

PERSON_CLASS = 0
CONF_TH = 0.25
IOU_TH = 0.5

INSIDE_RATIO_TH = 0.55
MAX_AREA_RATIO = 0.6
HAND_BAND = 0.55

EXCLUDE_CLASSES = {
    "chair", "couch", "bed", "dining table", "toilet",
    "tv", "bench", "refrigerator", "oven", "sink",
}

ROI_PADDING = 20
MIN_ROI_SIZE = 320
SCENE_MAX_SIZE = 640  # 전체 프레임 전달 시 축소 한계 (Gemma 속도)

FLIP_VERTICAL = True

# 카메라가 반시계 90도로 돌아가 있어 시계방향으로 되돌린다.
# 방향이 반대면 cv2.ROTATE_90_COUNTERCLOCKWISE, 필요 없으면 None.
ROTATE = cv2.ROTATE_90_CLOCKWISE

DISPLAY_HEIGHT = 720

PIPELINE = (
    "nvarguscamerasrc sensor-id=0 ! "
    "video/x-raw(memory:NVMM), "
    "width=1280, height=720, framerate=30/1 ! "
    "nvvidconv ! "
    "video/x-raw, format=BGRx ! "
    "videoconvert ! "
    "video/x-raw, format=BGR ! "
    "queue leaky=downstream max-size-buffers=1 ! "
    "appsink drop=true max-buffers=1 sync=false"
)


# ======================= 보조 함수 =======================


def box_area(box):
    x1, y1, x2, y2 = box
    return max(x2 - x1, 0) * max(y2 - y1, 0)


def intersection_area(box_a, box_b):
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b

    x1 = max(ax1, bx1)
    y1 = max(ay1, by1)
    x2 = min(ax2, bx2)
    y2 = min(ay2, by2)

    return max(x2 - x1, 0) * max(y2 - y1, 0)


def zone_of(box, image_width):
    """bbox 중심이 화면 가로 3등분 중 어디에 있는지."""
    x1, _, x2, _ = box
    center_x = (x1 + x2) / 2

    if center_x < image_width / 3:
        return "왼쪽"
    if center_x < image_width * 2 / 3:
        return "가운데"

    return "오른쪽"


def find_held_object(person, objects):
    """점수 = 사람 안에 들어간 비율 x confidence x 손 높이 근접도"""
    px1, py1, px2, py2 = person["bbox"]
    person_area = box_area(person["bbox"])
    person_height = max(py2 - py1, 1)

    hand_y = py1 + person_height * HAND_BAND

    best = None
    best_score = 0.0

    for obj in objects:
        if obj["class"] == "person":
            continue
        if obj["class"] in EXCLUDE_CLASSES:
            continue

        obj_area = box_area(obj["bbox"])

        if obj_area <= 0:
            continue
        if obj_area > person_area * MAX_AREA_RATIO:
            continue

        inside_ratio = intersection_area(person["bbox"], obj["bbox"]) / obj_area

        if inside_ratio < INSIDE_RATIO_TH:
            continue

        ox1, oy1, ox2, oy2 = obj["bbox"]
        obj_cy = (oy1 + oy2) / 2
        band_weight = 1.0 - min(abs(obj_cy - hand_y) / person_height, 1.0)

        score = inside_ratio * obj["confidence"] * (0.3 + 0.7 * band_weight)

        if score > best_score:
            best_score = score
            best = obj

    return best, best_score


def crop_roi(image, box, padding=ROI_PADDING):
    height, width = image.shape[:2]

    x1, y1, x2, y2 = box

    x1 = max(0, int(x1) - padding)
    y1 = max(0, int(y1) - padding)
    x2 = min(width, int(x2) + padding)
    y2 = min(height, int(y2) + padding)

    roi = image[y1:y2, x1:x2].copy()

    if roi.size == 0:
        return None

    roi_height, roi_width = roi.shape[:2]
    longest = max(roi_height, roi_width)

    if longest < MIN_ROI_SIZE:
        scale = MIN_ROI_SIZE / longest
        roi = cv2.resize(
            roi,
            (int(roi_width * scale), int(roi_height * scale)),
            interpolation=cv2.INTER_CUBIC,
        )

    return roi


def shrink_scene(image):
    """전체 프레임은 그대로 넘기면 느리므로 적당히 줄인다."""
    height, width = image.shape[:2]
    longest = max(height, width)

    if longest <= SCENE_MAX_SIZE:
        return image

    scale = SCENE_MAX_SIZE / longest

    return cv2.resize(image, (int(width * scale), int(height * scale)))


def save_payload(roi_image, meta):
    """이미지를 먼저, 메타 JSON을 나중에 저장한다. (음성 쪽은 메타만 감시)"""
    if roi_image is not None:
        if not cv2.imwrite(TEMP_ROI_IMAGE_PATH, roi_image):
            raise RuntimeError("ROI 이미지 저장에 실패했습니다.")

        os.replace(TEMP_ROI_IMAGE_PATH, ROI_IMAGE_PATH)

    with open(TEMP_ROI_META_PATH, "w", encoding="utf-8") as file:
        json.dump(meta, file, ensure_ascii=False, indent=4)

    os.replace(TEMP_ROI_META_PATH, ROI_META_PATH)


def build_payload(frame, objects, person, held, score, question, intent):
    """질문 종류에 따라 다른 이미지와 메타를 만든다."""
    height, width = frame.shape[:2]

    # 모든 intent에서 공통으로 넘기는 탐지 목록
    detections = [
        {
            "class": obj["class"],
            "confidence": round(obj["confidence"], 3),
            "zone": zone_of(obj["bbox"], width),
        }
        for obj in objects
    ]

    meta = {
        "intent": intent,
        "question": question,
        "image_width": width,
        "image_height": height,
        "detections": detections,
        "mode": "none",
        "hint": None,
        "score": 0.0,
        "has_image": False,
    }

    # --- 이미지가 필요 없는 질문 ---
    if intent in ("count", "position"):
        print(f"[{intent}] 탐지 {len(detections)}건 -> 이미지 없이 전달")
        return None, meta

    # --- 프레임 전체가 필요한 질문 ---
    if intent == "scene":
        meta["mode"] = "scene"
        meta["has_image"] = True
        print(f"[{intent}] 프레임 전체 전달")
        return shrink_scene(frame), meta

    # --- 들고 있는 물건이 필요한 질문 (identity, color) ---
    if person is None:
        print(f"[{intent}] 사람이 탐지되지 않았습니다.")
        return None, meta

    if held:
        meta["mode"] = "object"
        meta["hint"] = held["class"]
        meta["score"] = round(score, 3)
        meta["has_image"] = True
        print(f"[{intent}] YOLO 후보: {held['class']} (score {score:.2f})")
        return crop_roi(frame, held["bbox"]), meta

    meta["mode"] = "person"
    meta["has_image"] = True
    print(f"[{intent}] YOLO 후보 없음 -> 사람 전체 전달")

    return crop_roi(frame, person["bbox"], padding=10), meta


# ============================ main ============================

os.makedirs("src/output", exist_ok=True)

yolo = YOLO(YOLO_MODEL_PATH)

cap = cv2.VideoCapture(PIPELINE, cv2.CAP_GSTREAMER)

if not cap.isOpened():
    print("카메라를 열 수 없습니다.")
    exit()

print("q : 종료")
print("l : 수동 캡처")
print("음성 프로세스의 요청 대기 중...\n")

if os.path.exists(REQUEST_PATH):
    last_request = os.path.getmtime(REQUEST_PATH)
else:
    last_request = 0

while True:
    ret, frame = cap.read()
    key = cv2.waitKey(1) & 0xFF

    if not ret:
        break
    if key == ord("q"):
        break

    if FLIP_VERTICAL:
        frame = cv2.flip(frame, 0)

    # 반드시 predict 앞에서 회전해야 bbox 좌표가 회전된 프레임 기준이 된다
    if ROTATE is not None:
        frame = cv2.rotate(frame, ROTATE)

    results = yolo.predict(
        source=frame,
        conf=CONF_TH,
        iou=IOU_TH,
        verbose=False,
    )

    result = results[0]

    objects = []

    for box in result.boxes:
        class_id = int(box.cls[0].item())
        x1, y1, x2, y2 = box.xyxy[0].cpu().tolist()

        objects.append(
            {
                "class": result.names[class_id],
                "confidence": float(box.conf[0].item()),
                "bbox": [x1, y1, x2, y2],
            }
        )

    persons = [obj for obj in objects if obj["class"] == "person"]
    persons.sort(key=lambda o: box_area(o["bbox"]), reverse=True)

    person = persons[0] if persons else None
    held, score = find_held_object(person, objects) if person else (None, 0.0)

    # ---------- 화면 출력 ----------
    output_frame = result.plot()

    if held:
        hx1, hy1, hx2, hy2 = [int(v) for v in held["bbox"]]
        cv2.rectangle(output_frame, (hx1, hy1), (hx2, hy2), (0, 0, 255), 3)
        cv2.putText(
            output_frame,
            f"HELD? {held['class']} ({score:.2f})",
            (hx1, max(hy1 - 10, 20)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (0, 0, 255),
            2,
        )

    display_height, display_width = output_frame.shape[:2]

    if display_height > DISPLAY_HEIGHT:
        scale = DISPLAY_HEIGHT / display_height
        output_frame = cv2.resize(
            output_frame,
            (int(display_width * scale), DISPLAY_HEIGHT),
        )

    cv2.imshow("Held Object", output_frame)

    # ---------- 음성 요청 감지 ----------
    if os.path.exists(REQUEST_PATH):
        current_request = os.path.getmtime(REQUEST_PATH)

        if current_request != last_request:
            last_request = current_request

            with open(REQUEST_PATH, "r", encoding="utf-8") as file:
                request = json.load(file)

            question = request.get("question", "")
            intent = request.get("intent", "identity")

            print(f"\n[요청/{intent}] {question}")

            roi_image, meta = build_payload(
                frame, objects, person, held, score, question, intent
            )

            save_payload(roi_image, meta)

    if key == ord("l"):
        roi_image, meta = build_payload(
            frame, objects, person, held, score, "이게 뭐야?", "identity"
        )
        save_payload(roi_image, meta)


cap.release()
cv2.destroyAllWindows()
print("\nVision 프로세스를 종료했습니다.")
